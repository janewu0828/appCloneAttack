/** Automatically generated file. DO NOT MODIFY */
package irdc.ex06_08;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}