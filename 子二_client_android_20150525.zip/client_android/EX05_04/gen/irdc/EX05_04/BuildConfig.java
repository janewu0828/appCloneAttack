/** Automatically generated file. DO NOT MODIFY */
package irdc.EX05_04;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}