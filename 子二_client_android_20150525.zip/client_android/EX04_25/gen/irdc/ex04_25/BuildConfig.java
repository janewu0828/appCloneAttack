/** Automatically generated file. DO NOT MODIFY */
package irdc.ex04_25;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}