package trustedappframework.subprojecttwo.interfaces;

public interface MainInterface {

	public String sayHello();

	public void loadMethod();
}
