/** Automatically generated file. DO NOT MODIFY */
package irdc.ex04_16;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}